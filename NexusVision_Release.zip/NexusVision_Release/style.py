# style.py - Purple Theme System for Nexus Vision

class PurpleTheme:
    # Core colors
    BG_DARK = "#0D0A14"
    BG_MEDIUM = "#15101E"
    BG_LIGHT = "#1E1628"
    BG_CARD = "#1A1424"
    
    ACCENT_PRIMARY = "#8B3FD9"
    ACCENT_BRIGHT = "#B04DF5"
    ACCENT_GLOW = "#9E4AE8"
    ACCENT_DARK = "#6B2FB7"
    
    TEXT_PRIMARY = "#FFFFFF"
    TEXT_SECONDARY = "#B8B3C0"
    TEXT_DIM = "#6E6878"
    
    SUCCESS = "#5FE07A"
    ERROR = "#E84D5A"
    WARNING = "#E8B84D"
    DANGER = "#CC3344"
    
    BORDER = "#3D2E54"
    BORDER_LIGHT = "#4A3A64"
    
    # Gradient stops for advanced styling
    GRADIENT_START = "#9E4AE8"
    GRADIENT_END = "#6B2FB7"
    
    # Animation durations (ms)
    ANIM_FAST = 100
    ANIM_NORMAL = 200
    ANIM_SLOW = 300


# QSS Stylesheet for all widgets
NEXUS_STYLESHEET = f"""
/* Global Settings */
QWidget {{
    font-family: 'Segoe UI', 'Arial', sans-serif;
    font-size: 13px;
    color: {PurpleTheme.TEXT_PRIMARY};
}}

/* Main Window */
QMainWindow, QDialog {{
    background-color: {PurpleTheme.BG_DARK};
}}

/* Labels */
QLabel {{
    color: {PurpleTheme.TEXT_PRIMARY};
    background: transparent;
    border: none;
}}

QLabel#secondary {{
    color: {PurpleTheme.TEXT_SECONDARY};
}}

QLabel#dim {{
    color: {PurpleTheme.TEXT_DIM};
}}

QLabel#accent {{
    color: {PurpleTheme.ACCENT_BRIGHT};
}}

QLabel#success {{
    color: {PurpleTheme.SUCCESS};
}}

QLabel#error {{
    color: {PurpleTheme.ERROR};
}}

/* Title Labels */
QLabel#title {{
    font-size: 28px;
    font-weight: bold;
    color: {PurpleTheme.ACCENT_BRIGHT};
}}

QLabel#subtitle {{
    font-size: 14px;
    color: {PurpleTheme.TEXT_SECONDARY};
}}

QLabel#section {{
    font-size: 16px;
    font-weight: bold;
    color: {PurpleTheme.ACCENT_BRIGHT};
}}

/* Buttons */
QPushButton {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
    color: {PurpleTheme.TEXT_PRIMARY};
    border: none;
    border-radius: 6px;
    padding: 10px 20px;
    font-size: 13px;
    font-weight: 500;
}}

QPushButton:hover {{
    background-color: {PurpleTheme.ACCENT_BRIGHT};
}}

QPushButton:pressed {{
    background-color: {PurpleTheme.ACCENT_DARK};
}}

QPushButton:disabled {{
    background-color: {PurpleTheme.BG_LIGHT};
    color: {PurpleTheme.TEXT_DIM};
}}

QPushButton#danger {{
    background-color: {PurpleTheme.DANGER};
}}

QPushButton#danger:hover {{
    background-color: #DD4455;
}}

QPushButton#success {{
    background-color: {PurpleTheme.SUCCESS};
    color: {PurpleTheme.BG_DARK};
}}

QPushButton#success:hover {{
    background-color: #6FE88A;
}}

QPushButton#secondary {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 1px solid {PurpleTheme.BORDER};
}}

QPushButton#secondary:hover {{
    background-color: {PurpleTheme.BG_MEDIUM};
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QPushButton#big {{
    padding: 15px 30px;
    font-size: 15px;
}}

/* Input Fields */
QLineEdit {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 10px 14px;
    color: {PurpleTheme.TEXT_PRIMARY};
    selection-background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QLineEdit:hover {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QLineEdit:focus {{
    border-color: {PurpleTheme.ACCENT_BRIGHT};
    background-color: {PurpleTheme.BG_MEDIUM};
}}

QLineEdit:disabled {{
    background-color: {PurpleTheme.BG_DARK};
    color: {PurpleTheme.TEXT_DIM};
}}

/* ComboBox (Dropdown) */
QComboBox {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 10px 14px;
    color: {PurpleTheme.TEXT_PRIMARY};
    min-width: 120px;
}}

QComboBox:hover {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QComboBox:focus {{
    border-color: {PurpleTheme.ACCENT_BRIGHT};
}}

QComboBox::drop-down {{
    border: none;
    width: 30px;
}}

QComboBox::down-arrow {{
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid {PurpleTheme.TEXT_SECONDARY};
    margin-right: 10px;
}}

QComboBox QAbstractItemView {{
    background-color: {PurpleTheme.BG_MEDIUM};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    selection-background-color: {PurpleTheme.ACCENT_PRIMARY};
    selection-color: {PurpleTheme.TEXT_PRIMARY};
    padding: 5px;
}}

QComboBox QAbstractItemView::item {{
    padding: 8px 12px;
    border-radius: 4px;
}}

QComboBox QAbstractItemView::item:hover {{
    background-color: {PurpleTheme.ACCENT_DARK};
}}

/* Scroll Bar */
QScrollBar:vertical {{
    background-color: {PurpleTheme.BG_DARK};
    width: 12px;
    border-radius: 6px;
    margin: 0;
}}

QScrollBar::handle:vertical {{
    background-color: {PurpleTheme.BORDER};
    border-radius: 6px;
    min-height: 40px;
    margin: 2px;
}}

QScrollBar::handle:vertical:hover {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0;
}}

QScrollBar:horizontal {{
    background-color: {PurpleTheme.BG_DARK};
    height: 12px;
    border-radius: 6px;
}}

QScrollBar::handle:horizontal {{
    background-color: {PurpleTheme.BORDER};
    border-radius: 6px;
    min-width: 40px;
    margin: 2px;
}}

QScrollBar::handle:horizontal:hover {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

/* List Widget */
QListWidget {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 5px;
    outline: none;
}}

QListWidget::item {{
    background-color: transparent;
    border-radius: 4px;
    padding: 10px 12px;
    margin: 2px 0;
}}

QListWidget::item:hover {{
    background-color: {PurpleTheme.BG_MEDIUM};
}}

QListWidget::item:selected {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QListWidget::item:selected QLabel {{
    color: {PurpleTheme.TEXT_PRIMARY};
}}

/* Group Box */
QGroupBox {{
    font-size: 14px;
    font-weight: bold;
    color: {PurpleTheme.ACCENT_BRIGHT};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 8px;
    margin-top: 12px;
    padding: 15px;
}}

QGroupBox::title {{
    subcontrol-origin: margin;
    subcontrol-position: top left;
    padding: 0 8px;
    background-color: {PurpleTheme.BG_DARK};
}}

/* CheckBox */
QCheckBox {{
    color: {PurpleTheme.TEXT_PRIMARY};
    spacing: 8px;
}}

QCheckBox::indicator {{
    width: 20px;
    height: 20px;
    border-radius: 4px;
    border: 2px solid {PurpleTheme.BORDER};
    background-color: {PurpleTheme.BG_LIGHT};
}}

QCheckBox::indicator:hover {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QCheckBox::indicator:checked {{
    background-color: {PurpleTheme.ACCENT_BRIGHT};
    border-color: {PurpleTheme.ACCENT_BRIGHT};
    image: none;
}}

QCheckBox::indicator:checked:hover {{
    background-color: {PurpleTheme.ACCENT_GLOW};
}}

/* RadioButton */
QRadioButton {{
    color: {PurpleTheme.TEXT_PRIMARY};
    spacing: 8px;
}}

QRadioButton::indicator {{
    width: 18px;
    height: 18px;
    border-radius: 9px;
    border: 2px solid {PurpleTheme.BORDER};
    background-color: {PurpleTheme.BG_LIGHT};
}}

QRadioButton::indicator:hover {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QRadioButton::indicator:checked {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 2px solid {PurpleTheme.ACCENT_BRIGHT};
}}

QRadioButton::indicator:checked::after {{
    background-color: {PurpleTheme.ACCENT_BRIGHT};
    border-radius: 5px;
}}

/* Slider */
QSlider::groove:horizontal {{
    height: 6px;
    background-color: {PurpleTheme.BG_LIGHT};
    border-radius: 3px;
}}

QSlider::handle:horizontal {{
    width: 18px;
    height: 18px;
    background-color: {PurpleTheme.ACCENT_BRIGHT};
    border-radius: 9px;
    margin: -6px 0;
}}

QSlider::handle:horizontal:hover {{
    background-color: {PurpleTheme.ACCENT_GLOW};
}}

QSlider::sub-page:horizontal {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
    border-radius: 3px;
}}

/* SpinBox */
QSpinBox, QDoubleSpinBox {{
    background-color: {PurpleTheme.BG_LIGHT};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 8px 12px;
    color: {PurpleTheme.TEXT_PRIMARY};
}}

QSpinBox:hover, QDoubleSpinBox:hover {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QSpinBox:focus, QDoubleSpinBox:focus {{
    border-color: {PurpleTheme.ACCENT_BRIGHT};
}}

QSpinBox::up-button, QSpinBox::down-button,
QDoubleSpinBox::up-button, QDoubleSpinBox::down-button {{
    background-color: {PurpleTheme.BG_MEDIUM};
    border: none;
    width: 20px;
}}

QSpinBox::up-button:hover, QSpinBox::down-button:hover,
QDoubleSpinBox::up-button:hover, QDoubleSpinBox::down-button:hover {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

/* Tab Widget */
QTabWidget::pane {{
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 8px;
    background-color: {PurpleTheme.BG_DARK};
    margin-top: -1px;
}}

QTabBar::tab {{
    background-color: {PurpleTheme.BG_LIGHT};
    color: {PurpleTheme.TEXT_SECONDARY};
    border: 1px solid {PurpleTheme.BORDER};
    border-bottom: none;
    border-top-left-radius: 6px;
    border-top-right-radius: 6px;
    padding: 10px 20px;
    margin-right: 2px;
}}

QTabBar::tab:hover {{
    background-color: {PurpleTheme.BG_MEDIUM};
    color: {PurpleTheme.TEXT_PRIMARY};
}}

QTabBar::tab:selected {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
    color: {PurpleTheme.TEXT_PRIMARY};
}}

/* Scroll Area */
QScrollArea {{
    background-color: {PurpleTheme.BG_DARK};
    border: none;
}}

QScrollArea > QWidget > QWidget {{
    background-color: {PurpleTheme.BG_DARK};
}}

/* Frame */
QFrame {{
    background-color: transparent;
}}

QFrame#card {{
    background-color: {PurpleTheme.BG_CARD};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 8px;
}}

QFrame#separator {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
}}

/* ToolTip */
QToolTip {{
    background-color: {PurpleTheme.BG_MEDIUM};
    color: {PurpleTheme.TEXT_PRIMARY};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 4px;
    padding: 6px 10px;
}}
"""