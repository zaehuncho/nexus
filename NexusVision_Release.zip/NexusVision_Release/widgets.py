import math

# widgets.py - Custom UI Components for Nexus Vision

from PyQt6.QtWidgets import (
    QWidget, QPushButton, QLabel, QLineEdit, QComboBox,
    QFrame, QHBoxLayout, QVBoxLayout, QSizePolicy, QScrollArea,
    QGraphicsOpacityEffect, QStackedWidget
)
from PyQt6.QtCore import (
    Qt, QPropertyAnimation, QEasingCurve, QPoint, QSize,
    pyqtProperty, QTimer, QParallelAnimationGroup
)
from PyQt6.QtGui import QPainter, QColor, QPen, QBrush, QFont, QLinearGradient

from style import PurpleTheme


class AnimatedButton(QPushButton):
    """Button with smooth hover and press animations"""
    
    def __init__(self, text="", parent=None, style_type="primary"):
        super().__init__(text, parent)
        self.style_type = style_type
        self._opacity = 1.0
        self._glow_intensity = 0.0
        
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setProperty("class", style_type)
        self.setStyleSheet(self._get_style())
        
    def _get_style(self):
        base = f"""
            QPushButton {{
                background-color: {PurpleTheme.ACCENT_PRIMARY};
                color: {PurpleTheme.TEXT_PRIMARY};
                border: none;
                border-radius: 6px;
                padding: 12px 24px;
                font-size: 13px;
                font-weight: 600;
            }}
            QPushButton:hover {{
                background-color: {PurpleTheme.ACCENT_BRIGHT};
            }}
            QPushButton:pressed {{
                background-color: {PurpleTheme.ACCENT_DARK};
            }}
        """
        
        if self.style_type == "danger":
            base = f"""
                QPushButton {{
                    background-color: {PurpleTheme.DANGER};
                    color: {PurpleTheme.TEXT_PRIMARY};
                    border: none;
                    border-radius: 6px;
                    padding: 12px 24px;
                    font-size: 13px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    background-color: #DD4455;
                }}
                QPushButton:pressed {{
                    background-color: #AA2233;
                }}
            """
        elif self.style_type == "success":
            base = f"""
                QPushButton {{
                    background-color: {PurpleTheme.SUCCESS};
                    color: {PurpleTheme.BG_DARK};
                    border: none;
                    border-radius: 6px;
                    padding: 12px 24px;
                    font-size: 13px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    background-color: #6FE88A;
                }}
                QPushButton:pressed {{
                    background-color: #4FD06A;
                }}
            """
        elif self.style_type == "secondary":
            base = f"""
                QPushButton {{
                    background-color: {PurpleTheme.BG_LIGHT};
                    color: {PurpleTheme.TEXT_PRIMARY};
                    border: 1px solid {PurpleTheme.BORDER};
                    border-radius: 6px;
                    padding: 12px 24px;
                    font-size: 13px;
                    font-weight: 600;
                }}
                QPushButton:hover {{
                    background-color: {PurpleTheme.BG_MEDIUM};
                    border-color: {PurpleTheme.ACCENT_PRIMARY};
                }}
                QPushButton:pressed {{
                    background-color: {PurpleTheme.BG_DARK};
                }}
            """
        
        return base


class GlowButton(QPushButton):
    """Button with animated glow effect"""
    
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self._glow = 0.0
        self._animation = QPropertyAnimation(self, b"glow")
        self._animation.setDuration(200)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        
    def get_glow(self):
        return self._glow
    
    def set_glow(self, value):
        self._glow = value
        self.update()
    
    glow = pyqtProperty(float, get_glow, set_glow)
    
    def enterEvent(self, event):
        self._animation.setStartValue(self._glow)
        self._animation.setEndValue(1.0)
        self._animation.start()
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._animation.setStartValue(self._glow)
        self._animation.setEndValue(0.0)
        self._animation.start()
        super().leaveEvent(event)
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Background
        bg_color = QColor(PurpleTheme.ACCENT_PRIMARY)
        if self._glow > 0:
            glow_color = QColor(PurpleTheme.ACCENT_BRIGHT)
            bg_color = self._blend_colors(bg_color, glow_color, self._glow * 0.3)
        
        painter.setBrush(QBrush(bg_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(self.rect(), 6, 6)
        
        # Text
        painter.setPen(QColor(PurpleTheme.TEXT_PRIMARY))
        painter.setFont(self.font())
        painter.drawText(self.rect(), Qt.AlignmentFlag.AlignCenter, self.text())
    
    def _blend_colors(self, c1, c2, factor):
        r = c1.red() + (c2.red() - c1.red()) * factor
        g = c1.green() + (c2.green() - c1.green()) * factor
        b = c1.blue() + (c2.blue() - c1.blue()) * factor
        return QColor(int(r), int(g), int(b))


class ToggleSwitch(QWidget):
    """Animated toggle switch"""
    
    def __init__(self, parent=None, checked=False):
        super().__init__(parent)
        self._checked = checked
        self._position = 1.0 if checked else 0.0
        self._animation = QPropertyAnimation(self, b"position")
        self._animation.setDuration(200)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        
        self.setFixedSize(50, 26)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
    
    def get_position(self):
        return self._position
    
    def set_position(self, value):
        self._position = value
        self.update()
    
    position = pyqtProperty(float, get_position, set_position)
    
    def isChecked(self):
        return self._checked
    
    def setChecked(self, checked):
        if self._checked != checked:
            self._checked = checked
            self._animate()
            # Find parent and emit signal properly
            parent = self.parent()
            if parent and hasattr(parent, 'on_toggle'):
                parent.on_toggle(self, checked)
    
    def toggle(self):
        self.setChecked(not self._checked)
    
    def _animate(self):
        self._animation.setStartValue(self._position)
        self._animation.setEndValue(1.0 if self._checked else 0.0)
        self._animation.start()
    
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self.toggle()
    
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        
        # Track
        track_color = QColor(PurpleTheme.ACCENT_PRIMARY) if self._checked else QColor(PurpleTheme.BG_LIGHT)
        if 0 < self._position < 1:
            inactive = QColor(PurpleTheme.BG_LIGHT)
            track_color = self._blend_colors(inactive, QColor(PurpleTheme.ACCENT_PRIMARY), self._position)
        
        painter.setBrush(QBrush(track_color))
        painter.setPen(Qt.PenStyle.NoPen)
        painter.drawRoundedRect(0, 0, self.width(), self.height(), 13, 13)
        
        # Handle
        handle_margin = 3
        handle_size = self.height() - 2 * handle_margin
        handle_x = handle_margin + (self.width() - handle_size - 2 * handle_margin) * self._position
        
        painter.setBrush(QBrush(QColor(PurpleTheme.TEXT_PRIMARY)))
        painter.drawEllipse(int(handle_x), handle_margin, handle_size, handle_size)
    
    def _blend_colors(self, c1, c2, factor):
        r = c1.red() + (c2.red() - c1.red()) * factor
        g = c1.green() + (c2.green() - c1.green()) * factor
        b = c1.blue() + (c2.blue() - c1.blue()) * factor
        return QColor(int(r), int(g), int(b))


class CardWidget(QFrame):
    """Card container with subtle styling"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName("card")
        self.setStyleSheet(f"""
            QFrame#card {{
                background-color: {PurpleTheme.BG_CARD};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 8px;
            }}
        """)


class StatusBar(QWidget):
    """Status indicator with label"""
    
    def __init__(self, text="", status_type="default", parent=None):
        super().__init__(parent)
        layout = QHBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        
        self.indicator = QWidget()
        self.indicator.setFixedSize(8, 8)
        self._indicator_color = PurpleTheme.TEXT_SECONDARY
        
        self.label = QLabel(text)
        self.label.setStyleSheet(f"color: {PurpleTheme.TEXT_PRIMARY}; font-weight: 500;")
        
        layout.addWidget(self.indicator)
        layout.addWidget(self.label)
        layout.addStretch()
        
        self.set_status(status_type)
    
    def set_status(self, status_type):
        color_map = {
            "success": PurpleTheme.SUCCESS,
            "error": PurpleTheme.ERROR,
            "warning": PurpleTheme.WARNING,
            "active": PurpleTheme.ACCENT_BRIGHT,
            "default": PurpleTheme.TEXT_SECONDARY
        }
        self._indicator_color = color_map.get(status_type, PurpleTheme.TEXT_SECONDARY)
        self.indicator.update()
    
    def set_text(self, text):
        self.label.setText(text)


class SidebarButton(QPushButton):
    """Navigation button for sidebar"""
    
    def __init__(self, text="", icon="", parent=None):
        super().__init__(parent)
        self._is_active = False
        self._hover = False
        
        self.setText(f"  {icon}  {text}" if icon else f"  {text}")
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setFixedHeight(40)
        self._update_style()
    
    def set_active(self, active):
        self._is_active = active
        self._update_style()
    
    def isActive(self):
        return self._is_active
    
    def enterEvent(self, event):
        self._hover = True
        self._update_style()
        super().enterEvent(event)
    
    def leaveEvent(self, event):
        self._hover = False
        self._update_style()
        super().leaveEvent(event)
    
    def _update_style(self):
        if self._is_active:
            bg = PurpleTheme.ACCENT_PRIMARY
            color = PurpleTheme.TEXT_PRIMARY
        elif self._hover:
            bg = PurpleTheme.BG_LIGHT
            color = PurpleTheme.TEXT_PRIMARY
        else:
            bg = PurpleTheme.BG_DARK
            color = PurpleTheme.TEXT_SECONDARY
        
        self.setStyleSheet(f"""
            QPushButton {{
                background-color: {bg};
                color: {color};
                border: none;
                border-radius: 6px;
                text-align: left;
                padding: 0 15px;
                font-size: 13px;
                font-weight: 500;
            }}
        """)


class AnimatedStackedWidget(QStackedWidget):
    """Stacked widget with fade transitions"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self._opacity = 1.0
        self._animation = QPropertyAnimation(self, b"opacity")
        self._animation.setDuration(150)
        self._animation.setEasingCurve(QEasingCurve.Type.OutCubic)
    
    def get_opacity(self):
        return self._opacity
    
    def set_opacity(self, value):
        self._opacity = value
        for i in range(self.count()):
            widget = self.widget(i)
            if widget:
                effect = widget.graphicsEffect()
                if effect:
                    effect.setOpacity(value)
    
    opacity = pyqtProperty(float, get_opacity, set_opacity)
    
    def setCurrentIndex(self, index):
        if self.currentIndex() != index:
            for i in range(self.count()):
                widget = self.widget(i)
                if widget:
                    effect = QGraphicsOpacityEffect(widget)
                    effect.setOpacity(1.0)
                    widget.setGraphicsEffect(effect)
            super().setCurrentIndex(index)


class InputField(QLineEdit):
    """Styled input field with placeholder support"""
    
    def __init__(self, placeholder="", parent=None):
        super().__init__(parent)
        self.setPlaceholderText(placeholder)
        self.setStyleSheet(f"""
            QLineEdit {{
                background-color: {PurpleTheme.BG_LIGHT};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 6px;
                padding: 12px 16px;
                color: {PurpleTheme.TEXT_PRIMARY};
                font-size: 13px;
            }}
            QLineEdit:hover {{
                border-color: {PurpleTheme.ACCENT_PRIMARY};
            }}
            QLineEdit:focus {{
                border-color: {PurpleTheme.ACCENT_BRIGHT};
                background-color: {PurpleTheme.BG_MEDIUM};
            }}
        """)


class ComboBox(QComboBox):
    """Styled dropdown"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QComboBox {{
                background-color: {PurpleTheme.BG_LIGHT};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 6px;
                padding: 10px 14px;
                color: {PurpleTheme.TEXT_PRIMARY};
                font-size: 13px;
            }}
            QComboBox:hover {{
                border-color: {PurpleTheme.ACCENT_PRIMARY};
            }}
            QComboBox::drop-down {{
                border: none;
                width: 30px;
            }}
            QComboBox QAbstractItemView {{
                background-color: {PurpleTheme.BG_MEDIUM};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 6px;
                selection-background-color: {PurpleTheme.ACCENT_PRIMARY};
                padding: 5px;
            }}
        """)


class PulsingLabel(QLabel):
    """Label with pulsing animation"""
    
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self._opacity = 1.0
        self._animation = QPropertyAnimation(self, b"windowOpacity")
        self._animation.setDuration(2000)
        self._animation.setStartValue(0.7)
        self._animation.setEndValue(1.0)
        self._animation.setEasingCurve(QEasingCurve.Type.InOutSine)
        self._animation.setLoopCount(-1)
        
        # Use a timer for opacity effect on color
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._update_color)
        self._timer.start(16)
        
        self._time = 0
        self._base_color = QColor(PurpleTheme.ACCENT_BRIGHT)
    
    def _update_color(self):
        self._time += 0.03
        factor = 0.7 + 0.3 * ((1 + math.sin(self._time * 3.14159)) / 2)
        
        r = int(self._base_color.red() * factor)
        g = int(self._base_color.green() * factor)
        b = int(self._base_color.blue() * factor)
        
        self.setStyleSheet(f"color: rgb({r}, {g}, {b}); font-weight: bold;")
    
    def start_pulse(self):
        self._timer.start(16)
    
    def stop_pulse(self):
        self._timer.stop()


class SectionLabel(QLabel):
    """Styled section header"""
    
    def __init__(self, text="", parent=None):
        super().__init__(text, parent)
        self.setStyleSheet(f"""
            color: {PurpleTheme.TEXT_SECONDARY};
            font-size: 12px;
            font-weight: 600;
            letter-spacing: 1px;
        """)


class Divider(QFrame):
    """Horizontal divider line"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(1)
        self.setStyleSheet(f"background-color: {PurpleTheme.BORDER};")


class GlowDivider(QFrame):
    """Divider with accent color"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(2)
        self.setStyleSheet(f"background-color: {PurpleTheme.ACCENT_PRIMARY};")


class KeyDisplay(QWidget):
    """Widget for displaying generated keys with copy button"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(10)
        
        # Key label
        self.key_label = QLabel("")
        self.key_label.setStyleSheet(f"""
            color: {PurpleTheme.ACCENT_BRIGHT};
            font-size: 16px;
            font-family: 'Consolas', 'Courier New', monospace;
            font-weight: bold;
            background-color: {PurpleTheme.BG_LIGHT};
            padding: 15px;
            border-radius: 6px;
        """)
        self.key_label.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        self.key_label.hide()
        
        # Buttons
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(10)
        
        self.copy_btn = AnimatedButton("Copy to Clipboard", style_type="secondary")
        self.copy_btn.setFixedHeight(35)
        self.copy_btn.clicked.connect(self._copy_key)
        self.copy_btn.hide()
        
        self.clear_btn = AnimatedButton("Clear", style_type="secondary")
        self.clear_btn.setFixedHeight(35)
        self.clear_btn.setFixedWidth(80)
        self.clear_btn.hide()
        
        btn_layout.addWidget(self.copy_btn)
        btn_layout.addWidget(self.clear_btn)
        btn_layout.addStretch()
        
        layout.addWidget(self.key_label)
        layout.addLayout(btn_layout)
        
        self._key = ""
    
    def set_key(self, key):
        self._key = key
        if key:
            self.key_label.setText(key)
            self.key_label.show()
            self.copy_btn.show()
            self.clear_btn.show()
        else:
            self.key_label.hide()
            self.copy_btn.hide()
            self.clear_btn.hide()
    
    def get_key(self):
        return self._key
    
    def _copy_key(self):
        from PyQt6.QtWidgets import QApplication
        QApplication.clipboard().setText(self._key)