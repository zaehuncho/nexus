import sys
import os
import time
import json
import subprocess
import atexit

import cv2
import numpy as np

try:
    from gtuner import gcv_ready, gcv_write
except Exception:
    def gcv_ready():
        return False

    def gcv_write(_idx, _value):
        return


FONT = cv2.FONT_HERSHEY_DUPLEX
MORPH_KERNEL = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 5))

COLOR_NAME_TO_BGR = {
    "White":  (255, 255, 255),
    "Purple": (255, 0, 255),
    "Yellow": (0, 255, 255),
    "Red":    (0, 0, 255),
}

METER_REGION        = {"x": 5, "y": 250, "w": 1910, "h": 520}
USER_METER_COLOR    = (255, 255, 255)
METER_THRESHOLD_PX  = 95
MAX_METER_PX        = 95
TEMPO_DURATION      = 50
COLOR_TOLERANCE     = 40
SHOW_BBOX           = True
METER_ENABLED       = True
FADE_DURATION       = 132
STANDSTILL_DURATION = 50
TARGET_DISPLAY      = 152
TEMPO_ENABLED       = True
ONLINE_MODE         = False

RESET_DROP_PX       = 15
MIN_STABLE_FRAMES   = 3
MIN_OVER_FRAMES     = 1
REFRACTORY_FRAMES   = 10
STANDSTILL_VEL_THRESH = 2.5
VELOCITY_COMP_FACTOR  = 0.15
ADAPTIVE_MAX_DRIFT    = 5


class MeterCycle:
    def __init__(self, max_meter_px=95):
        self.state = "IDLE"
        self.baseline_start = None
        self.stable_count = 0
        self.over_count = 0
        self.refractory = 0
        self.peak = 0
        self.last_height = 0
        self.max_meter_px = max_meter_px

    def reset_cycle(self):
        self.state = "IDLE"
        self.baseline_start = None
        self.stable_count = 0
        self.over_count = 0
        self.peak = 0

    def update(self, h_now, want_px):
        try:
            h_now = max(0, min(self.max_meter_px, int(h_now)))
        except Exception:
            h_now = 0

        if self.refractory > 0:
            self.refractory -= 1

        if self.state in ("TRACKING", "FIRED", "COOLDOWN"):
            if (self.last_height - h_now) >= RESET_DROP_PX or h_now == 0:
                self.reset_cycle()

        if self.state == "IDLE":
            if h_now > 0:
                self.state = "ARMING"
                self.stable_count = 1
                self.baseline_start = h_now
                self.peak = h_now

        elif self.state == "ARMING":
            self.baseline_start = min(self.baseline_start, h_now)
            self.stable_count += 1
            self.peak = max(self.peak, h_now)
            if self.stable_count >= MIN_STABLE_FRAMES:
                self.state = "TRACKING"
                self.over_count = 0

        elif self.state == "TRACKING":
            self.peak = max(self.peak, h_now)
            growth = max(0, h_now - (self.baseline_start or 0))
            total_fill = min(self.max_meter_px, (self.baseline_start or 0) + growth)
            if total_fill >= want_px and self.refractory == 0:
                self.over_count += 1
            else:
                self.over_count = 0
            if self.over_count >= MIN_OVER_FRAMES:
                self.state = "FIRED"
                self.refractory = REFRACTORY_FRAMES
                self.last_height = h_now
                return "fire", total_fill
            self.last_height = h_now
            return "none", total_fill

        self.last_height = h_now
        total_fill = (
            h_now if self.baseline_start is None
            else min(self.max_meter_px, self.baseline_start + max(0, h_now - self.baseline_start))
        )
        return "none", total_fill


_settings_path_cache = None


def _find_settings_path():
    global _settings_path_cache
    if _settings_path_cache and os.path.exists(_settings_path_cache):
        return _settings_path_cache
    base_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()
    nexus_dir = os.path.join(
        os.environ.get("USERPROFILE", os.path.expanduser("~")),
        "Desktop", "NexusVision",
    )
    for d in (nexus_dir, base_dir):
        p = os.path.join(d, "settings.json")
        if os.path.exists(p):
            _settings_path_cache = p
            return p
    _settings_path_cache = os.path.join(nexus_dir, "settings.json")
    return _settings_path_cache


def _load_settings():
    global METER_REGION, USER_METER_COLOR, METER_THRESHOLD_PX
    global MAX_METER_PX, TEMPO_DURATION, COLOR_TOLERANCE
    global SHOW_BBOX, METER_ENABLED
    global FADE_DURATION, STANDSTILL_DURATION, TARGET_DISPLAY
    global TEMPO_ENABLED, ONLINE_MODE

    try:
        path = _find_settings_path()
        if not os.path.exists(path):
            return
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
    except Exception:
        return

    if "meter_enabled" in raw:
        METER_ENABLED = bool(raw["meter_enabled"])

    sr = raw.get("search_region")
    if isinstance(sr, dict):
        METER_REGION["x"] = int(sr.get("left",   METER_REGION["x"]))
        METER_REGION["y"] = int(sr.get("top",    METER_REGION["y"]))
        METER_REGION["w"] = int(sr.get("width",  METER_REGION["w"]))
        METER_REGION["h"] = int(sr.get("height", METER_REGION["h"]))

    color_name = raw.get("meter_color")
    if isinstance(color_name, str) and color_name in COLOR_NAME_TO_BGR:
        USER_METER_COLOR = COLOR_NAME_TO_BGR[color_name]

    fill_pct = raw.get("meter_fill_threshold")
    if fill_pct is not None:
        fill_pct = max(1, min(100, int(fill_pct)))
        METER_THRESHOLD_PX = max(1, min(MAX_METER_PX, int(round((fill_pct / 100.0) * MAX_METER_PX))))

    tol = raw.get("color_tolerance")
    if tol is not None:
        COLOR_TOLERANCE = max(10, min(120, int(tol)))

    td = raw.get("tempo_duration")
    if td is not None:
        TEMPO_DURATION = max(0, min(255, int(td)))

    if "show_bbox" in raw:
        SHOW_BBOX = bool(raw["show_bbox"])

    fd = raw.get("fade_duration")
    if fd is not None:
        FADE_DURATION = int(fd)

    sd = raw.get("standstill_duration")
    if sd is not None:
        STANDSTILL_DURATION = int(sd)

    td_disp = raw.get("meter_timing", raw.get("target_ms"))
    if td_disp is not None:
        TARGET_DISPLAY = int(td_disp)

    if "tempo" in raw:
        TEMPO_ENABLED = bool(raw["tempo"])

    if "online" in raw:
        ONLINE_MODE = bool(raw["online"])


def _load_meter_profiles():
    try:
        base_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()
        meters_dir = os.path.join(base_dir, "meters")
        if not os.path.isdir(meters_dir):
            return {}
        profiles = {}
        for name in os.listdir(meters_dir):
            if not name.lower().endswith(".json"):
                continue
            try:
                with open(os.path.join(meters_dir, name), "r", encoding="utf-8") as f:
                    profiles[str(json.load(f).get("style", os.path.splitext(name)[0]))] = True
            except Exception:
                continue
        return profiles
    except Exception:
        return {}


_WORKER_INSTANCE = None
_LAUNCHER_LAUNCHED = False


class GCVWorker:
    def __init__(self, width, height):
        self.width  = int(width)  if width  else 1920
        self.height = int(height) if height else 1080
        self.meter_cycle = MeterCycle(max_meter_px=MAX_METER_PX)

        self._settings_counter   = 0
        self._startup_frames     = 45
        self._frame_count        = 0
        self._pulse_until_ms     = 0.0
        self._pulse_ms           = 100.0
        self._current_shot_type  = "square"
        self.last_shot_time      = 0.0
        self.last_square_shot_time = 0.0
        self.last_tempo_shot_time  = 0.0
        self._shot_count         = 0
        self._prev_distance      = 0
        self._velocity           = 0.0
        self._adapted_offset     = 0
        self._fire_flash_frames  = 0
        self._post_fire_tracking = False
        self._post_fire_peak     = 0
        self._post_fire_countdown = 0

        _load_settings()
        _load_meter_profiles()
        self._start_launcher()

    def _start_launcher(self):
        global _LAUNCHER_LAUNCHED
        if _LAUNCHER_LAUNCHED:
            return
        _LAUNCHER_LAUNCHED = True
        try:
            base_dir = os.path.dirname(os.path.abspath(__file__)) or os.getcwd()
            nexus_dir = os.path.join(
                os.environ.get("USERPROFILE", os.path.expanduser("~")),
                "Desktop", "NexusVision",
            )
            for p in [
                os.path.join(nexus_dir, "NexusVision.exe"),
                os.path.join(nexus_dir, "dist", "NexusVision", "NexusVision.exe"),
                os.path.join(base_dir, "NexusVision.exe"),
            ]:
                if os.path.exists(p):
                    subprocess.Popen(
                        [p],
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                        creationflags=0x00000008 if sys.platform == "win32" else 0,
                    )
                    return
            py_launcher = os.path.join(base_dir, "Nexus_Vision_Launcher.py")
            if os.path.exists(py_launcher):
                subprocess.Popen(
                    [sys.executable, py_launcher],
                    stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                    creationflags=0x00000008 if sys.platform == "win32" else 0,
                )
        except Exception:
            pass

    def _start_pulse(self, shot_type="square"):
        self._pulse_ms = float(TEMPO_DURATION) if shot_type == "tempo" else 100.0
        self._pulse_until_ms = time.time() * 1000.0 + self._pulse_ms
        self._current_shot_type = shot_type

    def _service_output(self, out_bytes):
        now = time.time() * 1000.0
        if now < self._pulse_until_ms:
            if self._current_shot_type == "square":
                out_bytes[0], out_bytes[1] = 1, 1
            elif self._current_shot_type == "tempo":
                out_bytes[0], out_bytes[1] = 0, 1
            else:
                out_bytes[0], out_bytes[1] = 0, 0
        else:
            out_bytes[0], out_bytes[1] = 0, 0
        out_bytes[3] = TEMPO_DURATION

    def process(self, frame):
        out_bytes = bytearray(7)

        self._frame_count += 1
        self._settings_counter += 1
        if self._settings_counter % 15 == 0:
            _load_settings()
            self.meter_cycle.max_meter_px = MAX_METER_PX

        if frame is None or frame.size == 0:
            return frame, out_bytes

        H, W = frame.shape[:2]

        if self._frame_count <= self._startup_frames:
            card = frame.copy()
            cv2.rectangle(card, (W // 2 - 210, H // 2 - 60), (W // 2 + 210, H // 2 + 60), (0, 0, 0), -1)
            cv2.addWeighted(card, 0.35, frame, 0.65, 0, frame)
            cv2.putText(frame, "NEXUS VISION", (W // 2 - 160, H // 2 - 5), FONT, 1.1, (255, 212, 0), 2, cv2.LINE_AA)
            cv2.putText(frame, "Initializing...", (W // 2 - 160, H // 2 + 25), FONT, 0.55, (180, 180, 200), 1, cv2.LINE_AA)
            return frame, out_bytes

        detected          = False
        fill_pct          = 0
        distance          = 0
        status            = "IDLE"
        status_color      = (180, 180, 180)
        bbox_coords       = None
        rx = ry = rw = rh = 0
        effective_threshold = METER_THRESHOLD_PX + self._adapted_offset
        shot_type_label   = "TEMPO" if TEMPO_ENABLED else "SQ"

        if METER_ENABLED:
            rx = max(0, min(W - 1, METER_REGION["x"]))
            ry = max(0, min(H - 1, METER_REGION["y"]))
            rw = max(1, min(W - rx, METER_REGION["w"]))
            rh = max(1, min(H - ry, METER_REGION["h"]))
            roi = frame[ry:ry + rh, rx:rx + rw]

            cb, cg, cr = USER_METER_COLOR
            tol = COLOR_TOLERANCE
            lower = np.array([max(0, cb - tol), max(0, cg - tol), max(0, cr - tol)], dtype=np.uint8)
            upper = np.array([min(255, cb + tol), min(255, cg + tol), min(255, cr + tol)], dtype=np.uint8)

            mask   = cv2.inRange(roi, lower, upper)
            mask   = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, MORPH_KERNEL, iterations=1)
            pixels = cv2.findNonZero(mask)

            if pixels is not None and len(pixels) >= 30:
                detected = True
                y_coords = pixels[:, 0, 1]
                x_coords = pixels[:, 0, 0]
                top      = int(np.min(y_coords))
                bottom   = int(np.max(y_coords))
                left     = int(np.min(x_coords))
                right    = int(np.max(x_coords))
                distance = bottom - top

                vel_raw        = distance - self._prev_distance
                self._velocity = self._velocity * 0.7 + vel_raw * 0.3
                self._prev_distance = distance

                vel = abs(self._velocity)
                comp_frames = (FADE_DURATION if vel > STANDSTILL_VEL_THRESH else STANDSTILL_DURATION) / 16.67
                offset_px   = max(0, int(vel * comp_frames * VELOCITY_COMP_FACTOR))
                effective_threshold = max(10, METER_THRESHOLD_PX + self._adapted_offset - offset_px)

                action, total_fill = self.meter_cycle.update(distance, effective_threshold)
                fill_pct = max(0, min(100, int((total_fill / max(1, MAX_METER_PX)) * 100)))

                if self._post_fire_tracking:
                    self._post_fire_peak = max(self._post_fire_peak, distance)
                    self._post_fire_countdown -= 1
                    if self._post_fire_countdown <= 0:
                        self._post_fire_tracking = False
                        overshoot = self._post_fire_peak - effective_threshold
                        if overshoot > 10:
                            self._adapted_offset = min(ADAPTIVE_MAX_DRIFT, self._adapted_offset + 1)
                        elif overshoot < 2:
                            self._adapted_offset = max(-ADAPTIVE_MAX_DRIFT, self._adapted_offset - 1)

                now        = time.time()
                shot_fired = False

                if action == "fire" and (now - self.last_shot_time) > 0.15:
                    if TEMPO_ENABLED:
                        if (now - self.last_tempo_shot_time) > 0.10:
                            self._start_pulse("tempo")
                            self.last_tempo_shot_time = now
                            self.last_shot_time = now
                            shot_fired = True
                            if gcv_ready():
                                gcv_write(0, 0); gcv_write(1, 1); gcv_write(3, TEMPO_DURATION)
                    else:
                        if (now - self.last_square_shot_time) > 0.10:
                            self._start_pulse("square")
                            self.last_square_shot_time = now
                            self.last_shot_time = now
                            shot_fired = True
                            if gcv_ready():
                                gcv_write(0, 1); gcv_write(1, 1); gcv_write(3, TEMPO_DURATION)

                if shot_fired:
                    self._shot_count += 1
                    self._fire_flash_frames  = 18
                    self._post_fire_tracking = True
                    self._post_fire_peak     = distance
                    self._post_fire_countdown = 10
                    status, status_color = "FIRED", (0, 255, 0)
                elif distance >= effective_threshold * 0.8:
                    status, status_color = "LOCKED", (0, 255, 255)
                else:
                    status, status_color = "TRACKING", (255, 0, 255)

                bbox_coords = (rx + left, ry + top, rx + right, ry + bottom)
            else:
                self._prev_distance = 0
                self._velocity      = 0.0
                status, status_color = "IDLE", (180, 180, 180)

        self._service_output(out_bytes)
        out_bytes[4] = fill_pct
        out_bytes[5] = 1 if detected else 0

        if self._fire_flash_frames > 0:
            self._fire_flash_frames -= 1

        title   = "NEXUS VISION"
        rainbow = [
            (255, 255, 0), (200, 255, 50), (0, 255, 255), (0, 200, 255),
            (50, 100, 255), (255, 50, 255), (255, 0, 200), (255, 50, 100),
            (0, 255, 200), (100, 255, 100), (255, 200, 0), (0, 255, 255),
        ]
        (tw, _), _ = cv2.getTextSize(title, FONT, 1.0, 2)
        char_x = (W - tw) // 2
        for ci, ch in enumerate(title):
            col = rainbow[ci % len(rainbow)]
            cv2.putText(frame, ch, (char_x + 1, 31), FONT, 1.0, (0, 0, 0), 3, cv2.LINE_AA)
            cv2.putText(frame, ch, (char_x, 30),     FONT, 1.0, col,        2, cv2.LINE_AA)
            (cw, _), _ = cv2.getTextSize(ch, FONT, 1.0, 2)
            char_x += cw

        mode_str = "ONLINE" if ONLINE_MODE else "OFFLINE"
        mode_col = (0, 255, 100) if ONLINE_MODE else (100, 180, 255)
        cv2.putText(frame, mode_str,                               (14, 60),  FONT, 0.55, mode_col,       1, cv2.LINE_AA)
        cv2.putText(frame, f"State: {status}",                     (14, 82),  FONT, 0.50, status_color,   1, cv2.LINE_AA)
        cv2.putText(frame, f"Shot: {self._shot_count}  [{shot_type_label}]", (14, 104), FONT, 0.50, (160, 160, 180), 1, cv2.LINE_AA)

        eff_pct = max(0, min(100, int((effective_threshold / max(1, MAX_METER_PX)) * 100)))
        ri = W - 200
        cv2.putText(frame, f"Fade: {FADE_DURATION}ms",        (ri, 60),  FONT, 0.48, (220, 200, 50),  1, cv2.LINE_AA)
        cv2.putText(frame, f"Stand: {STANDSTILL_DURATION}ms", (ri, 80),  FONT, 0.48, (220, 200, 50),  1, cv2.LINE_AA)
        cv2.putText(frame, f"Target: {TARGET_DISPLAY}ms",     (ri, 100), FONT, 0.48, (0, 255, 80),    1, cv2.LINE_AA)
        cv2.putText(frame, f"Fill: {fill_pct}%",              (ri, 120), FONT, 0.48, (0, 200, 255),   1, cv2.LINE_AA)
        cv2.putText(frame, f"Vel: {self._velocity:+.1f} px/f",(ri, 140), FONT, 0.42, (200, 160, 255), 1, cv2.LINE_AA)
        cv2.putText(frame, f"Eff: {eff_pct}%",                (ri, 158), FONT, 0.42, (180, 255, 180), 1, cv2.LINE_AA)

        if self._fire_flash_frames > 0:
            ft = "FIRED!"
            (ftw, _), _ = cv2.getTextSize(ft, FONT, 0.90, 2)
            ftx = (W - ftw) // 2
            fty = H // 2 - 20
            cv2.putText(frame, ft, (ftx + 1, fty + 1), FONT, 0.90, (0, 0, 0),   4, cv2.LINE_AA)
            cv2.putText(frame, ft, (ftx, fty),          FONT, 0.90, (0, 255, 0), 2, cv2.LINE_AA)
        elif not detected and METER_ENABLED:
            nm = "NO METER DETECTED"
            (nmw, _), _ = cv2.getTextSize(nm, FONT, 0.70, 2)
            nmx = (W - nmw) // 2
            nmy = ry + rh // 2 if rh > 0 else H // 2
            cv2.putText(frame, nm, (nmx + 1, nmy + 1), FONT, 0.70, (0, 0, 0),    3, cv2.LINE_AA)
            cv2.putText(frame, nm, (nmx, nmy),          FONT, 0.70, (0, 50, 255), 2, cv2.LINE_AA)

        if detected and SHOW_BBOX and bbox_coords is not None:
            pad = 6
            bx1, by1, bx2, by2 = bbox_coords
            cv2.rectangle(frame,
                (max(0, bx1 - pad), max(0, by1 - pad)),
                (min(W - 1, bx2 + pad), min(H - 1, by2 + pad)),
                (0, 255, 80), 2)

        return frame, out_bytes

    def cleanup(self):
        pass


if '_WORKER_INSTANCE' not in globals() or _WORKER_INSTANCE is None:
    worker = GCVWorker(1920, 1080)
    _WORKER_INSTANCE = worker
    atexit.register(worker.cleanup)
else:
    worker = _WORKER_INSTANCE


def process_frame(frame):
    global _WORKER_INSTANCE
    frame, out_bytes = _WORKER_INSTANCE.process(frame)
    if gcv_ready():
        gcv_write(0, out_bytes[0])
        gcv_write(1, out_bytes[1])
        for i in range(2, len(out_bytes)):
            gcv_write(i, out_bytes[i])
    return frame
