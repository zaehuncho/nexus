#!/usr/bin/env python3
import sys
import json
import os
import uuid
import hashlib
import platform
import threading
import subprocess
import requests
from datetime import datetime

from PyQt6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
    QLabel, QDialog, QFrame, QSizePolicy, QSlider, QScrollArea,
    QSpinBox, QPushButton
)
from PyQt6.QtCore import Qt, QTimer, QObject, pyqtSignal
from PyQt6.QtGui import QColor, QPainter, QBrush, QPen

SERVER_URL = "https://nexus-vision-license.onrender.com"
CURRENT_VERSION = "1.0.0"
GITHUB_API = "https://api.github.com/repos/zaehuncho/nexus-vision-releases/releases/latest"

# ---------------------------------------------------------------------------
# Theme Colors
# ---------------------------------------------------------------------------

class PurpleTheme:
    BG_DARK = "#0E0720"
    BG_MAIN = "#1A0E2E"
    BG_MEDIUM = "#251640"
    BG_LIGHT = "#2D1F4A"
    BG_CARD = "#1F1535"
    
    ACCENT_PRIMARY = "#8B3FD9"
    ACCENT_BRIGHT = "#A855F7"
    ACCENT_GLOW = "#C084FC"
    
    TEXT_PRIMARY = "#FFFFFF"
    TEXT_SECONDARY = "#C4B5FD"
    TEXT_DIM = "#7C3AED"
    
    BORDER = "#3B2575"
    
    SUCCESS = "#10B981"
    WARNING = "#F59E0B"
    ERROR = "#EF4444"


NEXUS_STYLESHEET = f"""
QMainWindow, QWidget {{
    background-color: {PurpleTheme.BG_MAIN};
    color: {PurpleTheme.TEXT_PRIMARY};
    font-family: 'Segoe UI', Arial, sans-serif;
}}

QLabel {{
    color: {PurpleTheme.TEXT_PRIMARY};
}}

QPushButton {{
    background-color: {PurpleTheme.BG_LIGHT};
    color: {PurpleTheme.TEXT_PRIMARY};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 8px 16px;
    font-weight: 500;
}}

QPushButton:hover {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
    border-color: {PurpleTheme.ACCENT_BRIGHT};
}}

QPushButton:pressed {{
    background-color: {PurpleTheme.ACCENT_BRIGHT};
}}

QLineEdit {{
    background-color: {PurpleTheme.BG_DARK};
    color: {PurpleTheme.TEXT_PRIMARY};
    border: 1px solid {PurpleTheme.BORDER};
    border-radius: 6px;
    padding: 8px 12px;
}}

QLineEdit:focus {{
    border-color: {PurpleTheme.ACCENT_PRIMARY};
}}

QScrollArea {{
    border: none;
    background-color: transparent;
}}

QScrollBar:vertical {{
    background-color: {PurpleTheme.BG_DARK};
    width: 10px;
    border-radius: 5px;
}}

QScrollBar::handle:vertical {{
    background-color: {PurpleTheme.ACCENT_PRIMARY};
    border-radius: 5px;
    min-height: 20px;
}}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {{
    height: 0px;
}}
"""

# ---------------------------------------------------------------------------
# Thread Dispatcher
# ---------------------------------------------------------------------------

class _Dispatcher(QObject):
    _sig = pyqtSignal(object)

    def __init__(self):
        super().__init__()
        self._sig.connect(lambda fn: fn(), Qt.ConnectionType.QueuedConnection)

    def post(self, fn):
        self._sig.emit(fn)


_dispatch = _Dispatcher()


def run_bg(fn, cb=None):
    def _work():
        try:
            result = fn()
        except Exception:
            result = None
        if cb is not None:
            _dispatch.post(lambda: cb(result))
    threading.Thread(target=_work, daemon=True).start()


# ---------------------------------------------------------------------------
# License API
# ---------------------------------------------------------------------------

class LicenseAPI:
    def __init__(self, url):
        self.url = url

    def validate(self, key, mid):
        try:
            r = requests.post(
                f"{self.url}/api/validate",
                json={"key": key, "machine_id": mid},
                timeout=8
            )
            return r.json(), r.status_code
        except Exception as e:
            return {"valid": False, "error": str(e)}, 500

    def activate(self, key, mid):
        try:
            r = requests.post(
                f"{self.url}/api/activate",
                json={"key": key, "machine_id": mid},
                timeout=12
            )
            return r.json(), r.status_code
        except Exception as e:
            return {"success": False, "error": str(e)}, 500

    def get_status(self):
        try:
            r = requests.get(f"{self.url}/api/status", timeout=6)
            return r.json(), r.status_code
        except Exception:
            return {"status": "offline"}, 500

    def heartbeat(self, key, mid):
        try:
            r = requests.post(
                f"{self.url}/api/validate",
                json={"key": key, "machine_id": mid, "heartbeat": True},
                timeout=8
            )
            return r.json().get("valid", False)
        except Exception:
            return None


# ---------------------------------------------------------------------------
# File Helpers
# ---------------------------------------------------------------------------

def get_machine_id():
    raw = "|".join([str(uuid.getnode()), platform.node(), platform.processor()])
    return hashlib.sha256(raw.encode()).hexdigest()[:32]


NEXUS_DIR = os.path.join(os.environ.get("USERPROFILE", os.path.expanduser("~")), "Desktop", "NexusVision")
SETTINGS_FILE = os.path.join(NEXUS_DIR, "settings.json")
CACHE_FILE = os.path.join(NEXUS_DIR, "license_cache.json")


def _write_json(path, data):
    try:
        os.makedirs(NEXUS_DIR, exist_ok=True)
        with open(path, "w") as f:
            json.dump(data, f, indent=4)
    except Exception as e:
        print(f"[LAUNCHER] Write failed {path}: {e}")


def _read_json(path):
    try:
        if os.path.exists(path):
            with open(path) as f:
                return json.load(f)
    except Exception as e:
        print(f"[LAUNCHER] Read failed {path}: {e}")
    return None


def save_cache(d):
    _write_json(CACHE_FILE, d)


def load_cache():
    return _read_json(CACHE_FILE)


def clear_cache():
    try:
        if os.path.exists(CACHE_FILE):
            os.remove(CACHE_FILE)
    except Exception:
        pass


def save_settings(d):
    _write_json(SETTINGS_FILE, d)


def load_settings_file():
    return _read_json(SETTINGS_FILE) or {}


# ---------------------------------------------------------------------------
# Styles
# ---------------------------------------------------------------------------

SLIDER_STYLE = f"""
    QSlider::groove:horizontal {{
        height: 6px;
        background: {PurpleTheme.BG_LIGHT};
        border-radius: 3px;
    }}
    QSlider::handle:horizontal {{
        width: 16px;
        height: 16px;
        background: {PurpleTheme.ACCENT_BRIGHT};
        border-radius: 8px;
        margin: -5px 0;
    }}
    QSlider::handle:horizontal:hover {{
        background: #C85FFF;
    }}
    QSlider::sub-page:horizontal {{
        background: {PurpleTheme.ACCENT_PRIMARY};
        border-radius: 3px;
    }}
"""

SPIN_STYLE = f"""
    QSpinBox {{
        background: {PurpleTheme.BG_LIGHT};
        border: 1px solid {PurpleTheme.BORDER};
        border-radius: 6px;
        color: {PurpleTheme.ACCENT_BRIGHT};
        font-size: 13px;
        font-weight: bold;
        padding: 2px 4px;
    }}
    QSpinBox:hover {{ border-color: {PurpleTheme.ACCENT_PRIMARY}; }}
    QSpinBox::up-button, QSpinBox::down-button {{
        width: 14px;
        background: {PurpleTheme.BG_MEDIUM};
        border: none;
    }}
    QSpinBox::up-button:hover, QSpinBox::down-button:hover {{
        background: {PurpleTheme.ACCENT_PRIMARY};
    }}
"""


# ---------------------------------------------------------------------------
# CheckToggle
# ---------------------------------------------------------------------------

class CheckToggle(QWidget):
    def __init__(self, checked=False, on_change=None, parent=None):
        super().__init__(parent)
        self._checked = checked
        self._on_change = on_change
        self.setFixedSize(22, 22)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)

    def isChecked(self):
        return self._checked

    def setChecked(self, v):
        self._checked = bool(v)
        self.update()

    def toggle(self):
        self._checked = not self._checked
        self.update()
        if self._on_change:
            try:
                self._on_change()
            except Exception:
                pass

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self.toggle()
        e.accept()

    def mouseReleaseEvent(self, e):
        e.accept()

    def mouseDoubleClickEvent(self, e):
        e.accept()

    def paintEvent(self, e):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.setBrush(QBrush(QColor(0, 0, 0)))
        p.setPen(QPen(QColor(PurpleTheme.BORDER), 1.5))
        p.drawRoundedRect(1, 1, 20, 20, 4, 4)
        if self._checked:
            pen = QPen(QColor(255, 255, 255), 2.5)
            pen.setCapStyle(Qt.PenCapStyle.RoundCap)
            pen.setJoinStyle(Qt.PenJoinStyle.RoundJoin)
            p.setPen(pen)
            p.drawLine(5, 11, 9, 15)
            p.drawLine(9, 15, 17, 6)


# ---------------------------------------------------------------------------
# SafeSlider
# ---------------------------------------------------------------------------

class SafeSlider(QSlider):
    def mousePressEvent(self, e):
        super().mousePressEvent(e)
        e.accept()

    def mouseReleaseEvent(self, e):
        super().mouseReleaseEvent(e)
        e.accept()

    def mouseDoubleClickEvent(self, e):
        super().mouseDoubleClickEvent(e)
        e.accept()

    def mouseMoveEvent(self, e):
        super().mouseMoveEvent(e)
        e.accept()


# ---------------------------------------------------------------------------
# SliderSpin
# ---------------------------------------------------------------------------

class SliderSpin(QWidget):
    def __init__(self, label, lo, hi, val, key, ref, suffix=" ms", parent=None):
        super().__init__(parent)
        self.key = key
        self.ref = ref
        self._updating = False
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(10)

        lbl = QLabel(label)
        lbl.setFixedWidth(90)
        lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")

        self.sl = SafeSlider(Qt.Orientation.Horizontal)
        self.sl.setRange(lo, hi)
        self.sl.setValue(val)
        self.sl.setStyleSheet(SLIDER_STYLE)
        self.sl.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.sp = QSpinBox()
        self.sp.setRange(lo, hi)
        self.sp.setValue(val)
        self.sp.setSuffix(suffix)
        self.sp.setFixedWidth(78)
        self.sp.setFixedHeight(32)
        self.sp.setStyleSheet(SPIN_STYLE)
        self.sp.setFocusPolicy(Qt.FocusPolicy.StrongFocus)

        self.sl.valueChanged.connect(self._from_slider)
        self.sp.valueChanged.connect(self._from_spin)

        row.addWidget(lbl)
        row.addWidget(self.sl)
        row.addWidget(self.sp)

    def _from_slider(self, v):
        if self._updating:
            return
        self._updating = True
        self.sp.setValue(v)
        self._updating = False
        self.ref[self.key] = v
        save_settings(self.ref)

    def _from_spin(self, v):
        if self._updating:
            return
        self._updating = True
        self.sl.setValue(v)
        self._updating = False
        self.ref[self.key] = v
        save_settings(self.ref)

    def setValue(self, v):
        self._updating = True
        self.sl.setValue(v)
        self.sp.setValue(v)
        self._updating = False

    def value(self):
        return self.sl.value()

    def mousePressEvent(self, e):
        e.accept()

    def mouseReleaseEvent(self, e):
        e.accept()

    def mouseDoubleClickEvent(self, e):
        e.accept()


# ---------------------------------------------------------------------------
# TabBar
# ---------------------------------------------------------------------------

class TabBar(QWidget):
    def __init__(self, tabs, on_switch, parent=None):
        super().__init__(parent)
        self.setFixedHeight(46)
        self.setStyleSheet(f"background:{PurpleTheme.BG_DARK}; border-bottom:1px solid {PurpleTheme.BORDER};")
        self._btns = []
        self._cb = on_switch
        row = QHBoxLayout(self)
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        for text, pid in tabs:
            b = QPushButton(text)
            b.setCheckable(True)
            b.setCursor(Qt.CursorShape.PointingHandCursor)
            b.setFixedHeight(46)
            b.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Fixed)
            b.setStyleSheet(f"""
                QPushButton {{
                    background: transparent;
                    color: {PurpleTheme.TEXT_DIM};
                    border: none;
                    border-bottom: 2px solid transparent;
                    border-radius: 0;
                    font-size: 13px;
                    font-weight: 500;
                    letter-spacing: 1px;
                }}
                QPushButton:hover {{
                    color: {PurpleTheme.TEXT_PRIMARY};
                    background: rgba(255,255,255,0.04);
                }}
                QPushButton:checked {{
                    color: {PurpleTheme.ACCENT_BRIGHT};
                    border-bottom: 2px solid {PurpleTheme.ACCENT_BRIGHT};
                    font-weight: bold;
                    background: rgba(139,63,217,0.08);
                }}
            """)
            b.clicked.connect(lambda _, p=pid, btn=b: self._click(p, btn))
            self._btns.append((b, pid))
            row.addWidget(b, 1)

    def _click(self, pid, btn):
        for b, _ in self._btns:
            b.setChecked(False)
        btn.setChecked(True)
        self._cb(pid)

    def set_active(self, pid):
        for b, p in self._btns:
            b.setChecked(p == pid)


# ---------------------------------------------------------------------------
# Card
# ---------------------------------------------------------------------------

class Card(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QFrame {{
                background: {PurpleTheme.BG_CARD};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 8px;
            }}
        """)


# ---------------------------------------------------------------------------
# Divider
# ---------------------------------------------------------------------------

class Divider(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(1)
        self.setStyleSheet(f"background: {PurpleTheme.BORDER};")


# ---------------------------------------------------------------------------
# SectionLabel
# ---------------------------------------------------------------------------

class SectionLabel(QLabel):
    def __init__(self, text, parent=None):
        super().__init__(text, parent)
        self.setStyleSheet(f"color: {PurpleTheme.TEXT_DIM}; font-size: 11px; letter-spacing: 1px; font-weight: bold;")


# ---------------------------------------------------------------------------
# ComboBox
# ---------------------------------------------------------------------------

from PyQt6.QtWidgets import QComboBox

class ComboBox(QComboBox):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            QComboBox {{
                background: {PurpleTheme.BG_LIGHT};
                border: 1px solid {PurpleTheme.BORDER};
                border-radius: 6px;
                color: {PurpleTheme.TEXT_PRIMARY};
                padding: 6px 10px;
                font-size: 13px;
            }}
            QComboBox:hover {{
                border-color: {PurpleTheme.ACCENT_PRIMARY};
            }}
            QComboBox::drop-down {{
                border: none;
                width: 20px;
            }}
            QComboBox::down-arrow {{
                image: none;
                border-left: 4px solid transparent;
                border-right: 4px solid transparent;
                border-top: 6px solid {PurpleTheme.ACCENT_BRIGHT};
            }}
            QComboBox QAbstractItemView {{
                background: {PurpleTheme.BG_MEDIUM};
                border: 1px solid {PurpleTheme.BORDER};
                selection-background-color: {PurpleTheme.ACCENT_PRIMARY};
            }}
        """)


# ---------------------------------------------------------------------------
# Activation Dialog
# ---------------------------------------------------------------------------

class ActivationDialog(QDialog):
    def __init__(self, parent=None, api=None):
        super().__init__(parent)
        self.api = api
        self.setWindowTitle("NEXUS VISION")
        self.setFixedSize(440, 280)
        self.setModal(True)
        self.setStyleSheet(NEXUS_STYLESHEET)
        self._result = None
        self._busy = False

        lay = QVBoxLayout(self)
        lay.setContentsMargins(32, 32, 32, 32)
        lay.setSpacing(16)

        title = QLabel("ACTIVATE LICENSE")
        title.setStyleSheet(f"font-size:16px; font-weight:bold; color:{PurpleTheme.ACCENT_BRIGHT}; letter-spacing:2px;")
        lay.addWidget(title)

        sub = QLabel("Enter your license key to continue.")
        sub.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:12px;")
        lay.addWidget(sub)

        self.key_input = QLineEdit()
        self.key_input.setPlaceholderText("XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX")
        self.key_input.setFixedHeight(46)
        lay.addWidget(self.key_input)

        self.err = QLabel("")
        self.err.setStyleSheet(f"color:{PurpleTheme.ERROR}; font-size:12px;")
        self.err.setWordWrap(True)
        lay.addWidget(self.err)

        row = QHBoxLayout()
        self.ok_btn = QPushButton("ACTIVATE")
        self.ok_btn.setFixedHeight(42)
        self.ok_btn.clicked.connect(self._activate)
        ex = QPushButton("EXIT")
        ex.setFixedHeight(42)
        ex.setFixedWidth(90)
        ex.clicked.connect(self.reject)
        row.addWidget(self.ok_btn)
        row.addWidget(ex)
        lay.addLayout(row)

    def _activate(self):
        if self._busy:
            return
        key = self.key_input.text().strip()
        if not key:
            self.err.setText("Please enter a license key.")
            return
        self._busy = True
        self.ok_btn.setEnabled(False)
        self.err.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:12px;")
        self.err.setText("Connecting to server...")
        api = self.api
        mid = get_machine_id()

        def on_done(outcome):
            self._busy = False
            self.ok_btn.setEnabled(True)
            if outcome is None:
                self.err.setStyleSheet(f"color:{PurpleTheme.ERROR}; font-size:12px;")
                self.err.setText("Connection error. Try again.")
                return
            result, _ = outcome
            if result.get("success"):
                save_cache({
                    "key": key.upper(),
                    "user": result.get("user"),
                    "plan": result.get("plan"),
                    "expiry_date": result.get("expiry_date"),
                })
                self._result = result
                self.accept()
            else:
                msg = result.get("error", "Activation failed")
                if result.get("ban_reason"):
                    msg += f"\n{result.get('ban_reason')}"
                if "machine" in msg.lower() or "limit" in msg.lower():
                    msg = "This key is already activated on another machine.\nEach key is limited to 1 machine."
                self.err.setStyleSheet(f"color:{PurpleTheme.ERROR}; font-size:12px;")
                self.err.setText(msg)

        run_bg(lambda: api.activate(key, mid), on_done)

    def get_license(self):
        return self._result


# ---------------------------------------------------------------------------
# Meter Page
# ---------------------------------------------------------------------------

class MeterPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.s = load_settings_file()
        self._build()

    def _build(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        scroll.setStyleSheet("QScrollArea { border:none; background:transparent; }")

        content = QWidget()
        content.setStyleSheet("background:transparent;")
        lay = QVBoxLayout(content)
        lay.setContentsMargins(2, 2, 14, 8)
        lay.setSpacing(14)

        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.addWidget(scroll)
        scroll.setWidget(content)

        def row_toggle(label_text, key, default, bold=True):
            r = QHBoxLayout()
            l = QLabel(label_text)
            l.setStyleSheet(
                f"color:{PurpleTheme.TEXT_PRIMARY}; "
                f"font-size:{'14px' if bold else '13px'}; "
                f"font-weight:{'bold' if bold else 'normal'};"
            )
            chk = CheckToggle(self.s.get(key, default), self._save)
            setattr(self, f"chk_{key.replace('-', '_')}", chk)
            r.addWidget(l)
            r.addStretch()
            r.addWidget(chk)
            return r

        lay.addLayout(row_toggle("Meter Detection", "meter_enabled", True))
        lay.addWidget(Divider())

        sc = QHBoxLayout()
        sc.setSpacing(14)

        sl = QVBoxLayout()
        sl.setSpacing(5)
        sl.addWidget(SectionLabel("STYLE"))
        self.style_cb = ComboBox()
        self.style_cb.addItems(["Arrow", "Arrow2", "Straight", "Pill", "Sword", "Dial"])
        self.style_cb.setCurrentText(self.s.get("meter_style", "Arrow"))
        self.style_cb.setFixedHeight(38)
        self.style_cb.currentTextChanged.connect(self._save)
        sl.addWidget(self.style_cb)

        cl = QVBoxLayout()
        cl.setSpacing(5)
        cl.addWidget(SectionLabel("COLOR"))
        self.color_cb = ComboBox()
        self.color_cb.addItems(["Purple", "Yellow", "Red", "White"])
        self.color_cb.setCurrentText(self.s.get("meter_color", "Purple"))
        self.color_cb.setFixedHeight(38)
        self.color_cb.currentTextChanged.connect(self._save)
        cl.addWidget(self.color_cb)

        sc.addLayout(sl)
        sc.addLayout(cl)
        lay.addLayout(sc)
        lay.addWidget(Divider())

        lay.addWidget(SectionLabel("TIMING"))
        self.timing_sl = SliderSpin("Release", 0, 200, self.s.get("target_ms", 50), "target_ms", self.s)
        lay.addWidget(self.timing_sl)

        tr = QHBoxLayout()
        tr.setSpacing(16)

        tgt_col = QVBoxLayout()
        tgt_col.setSpacing(4)
        tgt_col.addWidget(SectionLabel("TARGET MS"))
        self.target_sp = QSpinBox()
        self.target_sp.setRange(0, 500)
        self.target_sp.setValue(self.s.get("target_ms", 50))
        self.target_sp.setSuffix(" ms")
        self.target_sp.setFixedHeight(34)
        self.target_sp.setStyleSheet(SPIN_STYLE)
        self.target_sp.valueChanged.connect(
            lambda v: (self.s.update({"target_ms": v}), save_settings(self.s))
        )
        tgt_col.addWidget(self.target_sp)

        tol_col = QVBoxLayout()
        tol_col.setSpacing(4)
        tol_col.addWidget(SectionLabel("TOLERANCE +/-"))
        self.tol_sp = QSpinBox()
        self.tol_sp.setRange(0, 100)
        self.tol_sp.setValue(self.s.get("tolerance_ms", 5))
        self.tol_sp.setSuffix(" ms")
        self.tol_sp.setFixedHeight(34)
        self.tol_sp.setStyleSheet(SPIN_STYLE)
        self.tol_sp.valueChanged.connect(
            lambda v: (self.s.update({"tolerance_ms": v}), save_settings(self.s))
        )
        tol_col.addWidget(self.tol_sp)

        tr.addLayout(tgt_col)
        tr.addLayout(tol_col)
        tr.addStretch()
        lay.addLayout(tr)

        for lbl, key, default in [
            ("Turbo Fade", "turbo", True),
            ("Fast No Dip", "fast_no_dip", False),
            ("Dunk with Stick", "dunk_stick", False),
        ]:
            lay.addLayout(row_toggle(lbl, key, default, bold=False))

        lay.addWidget(Divider())

        box = Card()
        bi = QVBoxLayout(box)
        bi.setContentsMargins(16, 14, 16, 16)
        bi.setSpacing(12)

        th = QHBoxLayout()
        tt = QLabel("TEMPO + CUE TIMINGS")
        tt.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:12px; font-weight:bold; letter-spacing:1px;")
        self.tempo_chk = CheckToggle(self.s.get("tempo", False), self._save)
        th.addWidget(tt)
        th.addStretch()
        th.addWidget(self.tempo_chk)
        bi.addLayout(th)

        rr = QHBoxLayout()
        rr.setSpacing(10)
        rl = QLabel("Rhythm Type")
        rl.setFixedWidth(100)
        rl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")
        self.rhythm_cb = ComboBox()
        self.rhythm_cb.addItems(["Button", "Stick"])
        self.rhythm_cb.setCurrentText(self.s.get("meter_rhythm", "Button"))
        self.rhythm_cb.setFixedHeight(34)
        self.rhythm_cb.currentTextChanged.connect(self._save)
        rr.addWidget(rl)
        rr.addWidget(self.rhythm_cb)
        bi.addLayout(rr)

        tsr = QHBoxLayout()
        tsr.setSpacing(10)
        tsl_lbl = QLabel("Tempo")
        tsl_lbl.setFixedWidth(100)
        tsl_lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")
        self.tempo_sl = SafeSlider(Qt.Orientation.Horizontal)
        self.tempo_sl.setRange(0, 100)
        self.tempo_sl.setValue(self.s.get("meter_tempo", 29))
        self.tempo_sl.setStyleSheet(SLIDER_STYLE)
        self.tempo_sl.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.tempo_v = QLabel(str(self.s.get("meter_tempo", 29)))
        self.tempo_v.setFixedWidth(32)
        self.tempo_v.setAlignment(Qt.AlignmentFlag.AlignRight)
        self.tempo_v.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:13px; font-weight:bold;")
        self.tempo_sl.valueChanged.connect(self._on_tempo)
        tsr.addWidget(tsl_lbl)
        tsr.addWidget(self.tempo_sl)
        tsr.addWidget(self.tempo_v)
        bi.addLayout(tsr)

        bi.addWidget(Divider())

        ct_lbl = QLabel("CUE TIMINGS")
        ct_lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:11px; letter-spacing:1px;")
        bi.addWidget(ct_lbl)

        self.fade_sl = SliderSpin("Fade", 0, 200, int(self.s.get("fade_duration", 50)), "fade_duration", self.s)
        self.ss_sl = SliderSpin("Standstill", 0, 200, int(self.s.get("standstill_duration", 50)), "standstill_duration", self.s)
        self.nd_sl = SliderSpin("No Dip", 0, 200, int(self.s.get("ms_cue", 60)), "ms_cue", self.s)
        bi.addWidget(self.fade_sl)
        bi.addWidget(self.ss_sl)
        bi.addWidget(self.nd_sl)

        lay.addWidget(box)
        lay.addWidget(Divider())
        lay.addLayout(row_toggle("Online Mode", "online", True))
        lay.addStretch()

    def _on_tempo(self, v):
        self.tempo_v.setText(str(v))
        self.s["meter_tempo"] = v
        save_settings(self.s)

    def load_settings(self):
        self.s = load_settings_file()
        self.fade_sl.setValue(int(self.s.get("fade_duration", 50)))
        self.ss_sl.setValue(int(self.s.get("standstill_duration", 50)))
        self.nd_sl.setValue(int(self.s.get("ms_cue", 60)))
        self.timing_sl.setValue(self.s.get("target_ms", self.s.get("meter_timing", 50)))
        self.target_sp.setValue(self.s.get("target_ms", 50))
        self.tol_sp.setValue(self.s.get("tolerance_ms", 5))
        self.tempo_sl.setValue(self.s.get("meter_tempo", 29))
        self.chk_online.setChecked(self.s.get("online", True))
        self.tempo_chk.setChecked(self.s.get("tempo", False))
        self.chk_meter_enabled.setChecked(self.s.get("meter_enabled", True))
        self.style_cb.setCurrentText(self.s.get("meter_style", "Arrow"))
        self.color_cb.setCurrentText(self.s.get("meter_color", "Purple"))
        self.rhythm_cb.setCurrentText(self.s.get("meter_rhythm", "Button"))
        self.chk_turbo.setChecked(self.s.get("turbo", True))
        self.chk_fast_no_dip.setChecked(self.s.get("fast_no_dip", False))
        self.chk_dunk_stick.setChecked(self.s.get("dunk_stick", False))

    def _save(self):
        try:
            self.s["meter_enabled"] = self.chk_meter_enabled.isChecked()
            self.s["meter_style"] = self.style_cb.currentText()
            self.s["meter_color"] = self.color_cb.currentText()
            self.s["target_ms"] = self.timing_sl.value()
            self.s["meter_timing"] = self.timing_sl.value()
            self.s["meter_tempo"] = self.tempo_sl.value()
            self.s["tempo"] = self.tempo_chk.isChecked()
            self.s["online"] = self.chk_online.isChecked()
            self.s["turbo"] = self.chk_turbo.isChecked()
            self.s["fast_no_dip"] = self.chk_fast_no_dip.isChecked()
            self.s["dunk_stick"] = self.chk_dunk_stick.isChecked()
            self.s["meter_rhythm"] = self.rhythm_cb.currentText()
            save_settings(self.s)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Debug Page
# ---------------------------------------------------------------------------

class DebugPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._logs = []
        self._build()
        t = QTimer(self)
        t.timeout.connect(self._refresh)
        t.start(1500)

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(12)

        title = QLabel("DEBUG")
        title.setStyleSheet(f"font-size:22px; font-weight:bold; color:{PurpleTheme.ACCENT_BRIGHT}; letter-spacing:3px;")
        lay.addWidget(title)
        lay.addWidget(Divider())
        lay.addWidget(SectionLabel("LIVE VARIABLES"))

        var_card = Card()
        vl = QVBoxLayout(var_card)
        vl.setContentsMargins(14, 12, 14, 12)
        vl.setSpacing(4)
        self.var_labels = {}
        keys = [
            "fade_duration", "standstill_duration", "ms_cue", "meter_timing",
            "target_ms", "tolerance_ms", "tempo", "online", "turbo",
            "fast_no_dip", "dunk_stick", "meter_enabled", "meter_style", "meter_color",
        ]
        for k in keys:
            r = QHBoxLayout()
            kl = QLabel(k)
            kl.setFixedWidth(160)
            kl.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:11px;")
            vv = QLabel("--")
            vv.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:11px; font-weight:bold;")
            r.addWidget(kl)
            r.addWidget(vv)
            r.addStretch()
            vl.addLayout(r)
            self.var_labels[k] = vv
        lay.addWidget(var_card)

        lay.addWidget(SectionLabel("LOG"))
        self.log_scroll = QScrollArea()
        self.log_scroll.setWidgetResizable(True)
        self.log_scroll.setFixedHeight(148)
        self.log_scroll.setStyleSheet(
            f"QScrollArea {{ background:{PurpleTheme.BG_CARD}; border:1px solid {PurpleTheme.BORDER}; border-radius:6px; }}"
        )
        log_inner = QWidget()
        self.log_lay = QVBoxLayout(log_inner)
        self.log_lay.setContentsMargins(10, 6, 10, 6)
        self.log_lay.setSpacing(1)
        self.log_lay.addStretch()
        self.log_scroll.setWidget(log_inner)
        lay.addWidget(self.log_scroll)

        cb = QPushButton("Clear Logs")
        cb.setFixedHeight(32)
        cb.setFixedWidth(110)
        cb.clicked.connect(self._clear)
        lay.addWidget(cb)
        lay.addStretch()
        self.add_log("Session started.")

    def _refresh(self):
        s = load_settings_file()
        for k, lbl in self.var_labels.items():
            val = s.get(k)
            if val is None:
                lbl.setText("--")
                lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:11px; font-weight:bold;")
            else:
                lbl.setText(str(val))
                lbl.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:11px; font-weight:bold;")

    def add_log(self, msg):
        ts = datetime.now().strftime("%H:%M:%S")
        e = QLabel(f"[{ts}]  {msg}")
        e.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:11px; font-family:monospace;")
        self.log_lay.insertWidget(self.log_lay.count() - 1, e)
        self._logs.append(e)
        QTimer.singleShot(40, lambda: self.log_scroll.verticalScrollBar().setValue(
            self.log_scroll.verticalScrollBar().maximum()
        ))

    def _clear(self):
        for e in self._logs:
            e.deleteLater()
        self._logs.clear()
        self.add_log("Logs cleared.")


# ---------------------------------------------------------------------------
# Network Page
# ---------------------------------------------------------------------------

PS5_MAC_PREFIXES = [
    "00:04:1f", "00:13:15", "00:15:c1", "00:19:c5", "00:1d:0d", "00:1e:3d",
    "00:1f:a7", "00:24:8d", "28:3f:69", "2c:76:8a", "70:9e:29", "78:c8:81",
    "a8:e3:ee", "bc:60:a7", "d8:4b:1d", "f8:46:1c", "0c:47:c9", "10:62:d9",
    "1c:98:c1", "20:df:b9",
]


def _find_ps5_ip():
    try:
        out = subprocess.run(
            ["arp", "-a"],
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=subprocess.CREATE_NO_WINDOW
        ).stdout
        for line in out.split("\n"):
            ll = line.lower()
            if any(p in ll for p in PS5_MAC_PREFIXES):
                for part in line.split():
                    if part.count(".") == 3:
                        return part.strip("()")
    except Exception:
        pass
    return None


def _ping_ms(host):
    try:
        if platform.system() == "Windows":
            args = ["ping", "-n", "1", "-w", "2000", host]
            creation_flags = subprocess.CREATE_NO_WINDOW
        else:
            args = ["ping", "-c", "1", host]
            creation_flags = 0
        out = subprocess.run(
            args,
            capture_output=True,
            text=True,
            timeout=5,
            creationflags=creation_flags
        ).stdout
        for line in out.split("\n"):
            if "time=" in line or "time<" in line:
                return line.split("time")[1].split("ms")[0].replace("=", "").replace("<", "").strip() + " ms"
    except Exception:
        pass
    return None


class NetworkPage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._ps5_ip = None
        self._scanning = False
        self._build()
        t = QTimer(self)
        t.timeout.connect(self._refresh)
        t.start(6000)
        QTimer.singleShot(1200, self._refresh)

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(14)

        title = QLabel("NETWORK")
        title.setStyleSheet(f"font-size:22px; font-weight:bold; color:{PurpleTheme.ACCENT_BRIGHT}; letter-spacing:3px;")
        lay.addWidget(title)
        lay.addWidget(Divider())

        hdr = QLabel("PS5 CONNECTION")
        hdr.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:11px; letter-spacing:2px; font-weight:bold;")
        lay.addWidget(hdr)

        card = Card()
        pl = QVBoxLayout(card)
        pl.setContentsMargins(18, 14, 18, 14)
        pl.setSpacing(10)
        self.ps5_labels = {}
        for key in ["PS5 IP", "Ping", "Status", "Connection Quality"]:
            r = QHBoxLayout()
            kl = QLabel(key)
            kl.setFixedWidth(150)
            kl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")
            vl = QLabel("--")
            vl.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:13px; font-weight:bold;")
            r.addWidget(kl)
            r.addWidget(vl)
            r.addStretch()
            pl.addLayout(r)
            self.ps5_labels[key] = vl
        lay.addWidget(card)

        rb = QPushButton("Refresh")
        rb.setFixedHeight(34)
        rb.setFixedWidth(100)
        rb.clicked.connect(self._refresh)
        lay.addWidget(rb)
        lay.addStretch()

    def _refresh(self):
        if self._scanning:
            return
        self._scanning = True
        known = self._ps5_ip

        def scan():
            ip = known or _find_ps5_ip()
            return {"ip": ip, "ping": _ping_ms(ip) if ip else None}

        def on_done(data):
            self._scanning = False
            if not data:
                return
            ip = data.get("ip")
            ping = data.get("ping")
            if ip:
                self._ps5_ip = ip
                self.ps5_labels["PS5 IP"].setText(ip)
                self.ps5_labels["PS5 IP"].setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:13px; font-weight:bold;")
                if ping:
                    self.ps5_labels["Ping"].setText(ping)
                    self.ps5_labels["Status"].setText("Online")
                    self.ps5_labels["Status"].setStyleSheet(f"color:{PurpleTheme.SUCCESS}; font-size:13px; font-weight:bold;")
                    try:
                        ms = float(ping.replace(" ms", "").replace("<", ""))
                        if ms < 30:
                            q, c = "Excellent", PurpleTheme.SUCCESS
                        elif ms < 60:
                            q, c = "Good", PurpleTheme.SUCCESS
                        elif ms < 100:
                            q, c = "Fair", PurpleTheme.WARNING
                        else:
                            q, c = "Poor", PurpleTheme.ERROR
                        self.ps5_labels["Connection Quality"].setText(q)
                        self.ps5_labels["Connection Quality"].setStyleSheet(f"color:{c}; font-size:13px; font-weight:bold;")
                    except Exception:
                        pass
                else:
                    self.ps5_labels["Status"].setText("Unreachable")
                    self.ps5_labels["Status"].setStyleSheet(f"color:{PurpleTheme.ERROR}; font-size:13px; font-weight:bold;")
            else:
                self.ps5_labels["PS5 IP"].setText("Not found on network")
                self.ps5_labels["PS5 IP"].setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:13px;")

        run_bg(scan, on_done)


# ---------------------------------------------------------------------------
# Update Page
# ---------------------------------------------------------------------------

class UpdatePage(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        lay = QVBoxLayout(self)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(16)

        title = QLabel("UPDATE")
        title.setStyleSheet(f"font-size:22px; font-weight:bold; color:{PurpleTheme.ACCENT_BRIGHT}; letter-spacing:3px;")
        lay.addWidget(title)
        lay.addWidget(Divider())

        c = Card()
        cl = QHBoxLayout(c)
        cl.setContentsMargins(20, 16, 20, 16)
        vl = QLabel("Installed Version")
        vl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")
        vv = QLabel(f"v{CURRENT_VERSION}")
        vv.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:15px; font-weight:bold;")
        cl.addWidget(vl)
        cl.addStretch()
        cl.addWidget(vv)
        lay.addWidget(c)

        self.status_lbl = QLabel("Checking for updates...")
        self.status_lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:13px;")
        lay.addWidget(self.status_lbl)

        note = QLabel("Run Updater.exe to apply available updates.")
        note.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:12px;")
        lay.addWidget(note)
        lay.addStretch()

        QTimer.singleShot(1200, self._check)

    def _check(self):
        def fetch():
            try:
                return requests.get(GITHUB_API, timeout=6).json().get("tag_name", "").lstrip("v")
            except Exception:
                return None

        def on_done(latest):
            if latest and latest != CURRENT_VERSION:
                self.status_lbl.setText(f"Update available: v{latest}  -  Run Updater.exe to update.")
                self.status_lbl.setStyleSheet(f"color:{PurpleTheme.WARNING}; font-size:13px; font-weight:bold;")
            elif latest:
                self.status_lbl.setText("You are up to date.")
                self.status_lbl.setStyleSheet(f"color:{PurpleTheme.SUCCESS}; font-size:13px;")
            else:
                self.status_lbl.setText("Could not check for updates.")
                self.status_lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:13px;")

        run_bg(fetch, on_done)


# ---------------------------------------------------------------------------
# Main Window
# ---------------------------------------------------------------------------

class LauncherWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("NEXUS VISION")
        self.setFixedSize(900, 620)
        self.setStyleSheet(
            NEXUS_STYLESHEET +
            "QMainWindow, QWidget { background-color: #1A0E2E; }"
            "QScrollArea QWidget { background-color: transparent; }"
        )

        self.api = LicenseAPI(SERVER_URL)
        self.licensed = False
        self.license_info = {}
        self._heartbeat_failures = 0
        self._activating = False

        self._build()
        QTimer.singleShot(0, self._resolve_license)

        self._hb_timer = QTimer(self)
        self._hb_timer.timeout.connect(self._heartbeat)
        self._hb_timer.start(600000)

    def _build(self):
        central = QWidget()
        self.setCentralWidget(central)
        root = QVBoxLayout(central)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        hdr = QWidget()
        hdr.setFixedHeight(52)
        hdr.setStyleSheet(f"background:#0E0720; border-bottom:1px solid {PurpleTheme.BORDER};")
        hl = QHBoxLayout(hdr)
        hl.setContentsMargins(20, 0, 20, 0)
        hl.setSpacing(8)

        logo = QLabel("NEXUS VISION")
        logo.setStyleSheet(f"color:{PurpleTheme.ACCENT_BRIGHT}; font-size:16px; font-weight:bold; letter-spacing:3px;")
        ver_lbl = QLabel(f"v{CURRENT_VERSION}")
        ver_lbl.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:11px;")
        hl.addWidget(logo)
        hl.addWidget(ver_lbl)

        self.update_lbl = QLabel("  UPDATE AVAILABLE")
        self.update_lbl.setStyleSheet(
            f"color:{PurpleTheme.WARNING}; font-size:11px; font-weight:bold; "
            f"background:#2a1a00; border:1px solid {PurpleTheme.WARNING}; "
            f"border-radius:4px; padding:2px 8px; letter-spacing:1px;"
        )
        self.update_lbl.hide()
        hl.addWidget(self.update_lbl)
        hl.addStretch()

        self.h_user = QLabel("")
        self.h_plan = QLabel("")
        self.h_exp = QLabel("")
        self.h_server = QLabel("* --")
        self.h_server.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; font-size:12px;")

        for w in [self.h_user, self.h_plan, self.h_exp]:
            w.setStyleSheet(f"color:{PurpleTheme.TEXT_SECONDARY}; font-size:12px;")
            hl.addWidget(w)
            sep = QLabel("|")
            sep.setStyleSheet(f"color:{PurpleTheme.TEXT_DIM}; margin:0 6px; font-size:12px;")
            hl.addWidget(sep)
        hl.addWidget(self.h_server)
        root.addWidget(hdr)

        self.tab_bar = TabBar(
            [("Meter", "METER"), ("Network", "NETWORK"), ("Update", "UPDATE"), ("Debug", "DEBUG")],
            self._switch
        )
        root.addWidget(self.tab_bar)

        wrap = QWidget()
        wrap.setStyleSheet("background:#1A0E2E;")
        wl = QVBoxLayout(wrap)
        wl.setContentsMargins(28, 22, 28, 22)

        from PyQt6.QtWidgets import QStackedWidget
        self.pages = QStackedWidget()
        self.meter_page = MeterPage()
        self.network_page = NetworkPage()
        self.update_page = UpdatePage()
        self.debug_page = DebugPage()

        for p in [self.meter_page, self.network_page, self.update_page, self.debug_page]:
            self.pages.addWidget(p)

        wl.addWidget(self.pages)
        root.addWidget(wrap)

        self.meter_page.load_settings()
        self._switch("METER")

    def _switch(self, pid):
        m = {"METER": 0, "NETWORK": 1, "UPDATE": 2, "DEBUG": 3}
        if pid in m:
            self.pages.setCurrentIndex(m[pid])
            self.tab_bar.set_active(pid)

    def _resolve_license(self):
        cache = load_cache()
        if not cache or not cache.get("key"):
            self._show_act()
            return

        key = cache["key"]
        mid = get_machine_id()
        api = self.api

        def on_done(res):
            if res is None:
                self.licensed = True
                self.license_info = cache
                self.debug_page.add_log("Validation error - using cached license.")
            else:
                result, status_code = res
                server_err = status_code >= 500 or "error" in result or result.get("valid") is None
                if result.get("valid"):
                    self.licensed = True
                    self.license_info = {
                        "key": cache.get("key"),
                        "user": result.get("user") or cache.get("user", ""),
                        "plan": result.get("plan") or cache.get("plan", ""),
                        "expiry_date": result.get("expiry_date") or cache.get("expiry_date", ""),
                    }
                    save_cache(self.license_info)
                    self.debug_page.add_log(f"License OK: {self.license_info.get('user')} [{self.license_info.get('plan')}]")
                elif server_err:
                    self.licensed = True
                    self.license_info = cache
                    self.debug_page.add_log("Server unreachable - using cached license.")
                else:
                    self.licensed = False
                    self.license_info = {}
                    clear_cache()
                    self.debug_page.add_log("License invalid or expired.")

            self._update_ui()
            if self.licensed:
                self.show()
                self.activateWindow()
                self.raise_()
                self._ping_server()
                self._check_version()
            else:
                self._show_act()

        run_bg(lambda: api.validate(key, mid), on_done)

    def _ping_server(self):
        api = self.api

        def on_done(res):
            ok = res and res[0].get("status") == "online"
            self.h_server.setText("* Online" if ok else "* Offline")
            self.h_server.setStyleSheet(
                f"color:{PurpleTheme.SUCCESS if ok else PurpleTheme.ERROR}; font-size:12px;"
            )
            self.debug_page.add_log(f"Server {'online' if ok else 'offline'}.")

        run_bg(api.get_status, on_done)

    def _check_version(self):
        def fetch():
            try:
                return requests.get(GITHUB_API, timeout=6).json().get("tag_name", "").lstrip("v")
            except Exception:
                return None

        def on_done(latest):
            if latest and latest != CURRENT_VERSION:
                self.update_lbl.setText(f"  UPDATE AVAILABLE  v{latest}  ")
                self.update_lbl.show()
                self.debug_page.add_log(f"Update available: v{latest}")
            else:
                self.update_lbl.hide()

        run_bg(fetch, on_done)

    def _heartbeat(self):
        if not self.licensed:
            return
        cache = load_cache()
        if not cache:
            return
        key = cache.get("key")
        mid = get_machine_id()
        api = self.api

        def on_done(result):
            if result is False:
                self._heartbeat_failures += 1
                self.debug_page.add_log(f"Heartbeat failed ({self._heartbeat_failures}/3)")
                if self._heartbeat_failures >= 3:
                    self.licensed = False
                    clear_cache()
                    self._update_ui()
                    if not self._activating:
                        self._show_act()
            elif result is True:
                self._heartbeat_failures = 0

        run_bg(lambda: api.heartbeat(key, mid), on_done)

    def _update_ui(self):
        if self.licensed:
            u = self.license_info.get("user", "")
            p = self.license_info.get("plan", "")
            e = self.license_info.get("expiry_date", "")
            self.h_user.setText(f"<b style='color:{PurpleTheme.TEXT_DIM};font-size:11px;'>USER</b> <span style='color:{PurpleTheme.ACCENT_BRIGHT};'>{u}</span>")
            self.h_plan.setText(f"<b style='color:{PurpleTheme.TEXT_DIM};font-size:11px;'>PLAN</b> <span style='color:{PurpleTheme.SUCCESS};'>{p}</span>")
            self.h_exp.setText(f"<b style='color:{PurpleTheme.TEXT_DIM};font-size:11px;'>EXP</b> <span style='color:{PurpleTheme.WARNING};'>{e}</span>")
        else:
            self.h_user.setText(f"<span style='color:{PurpleTheme.ERROR}; font-size:12px;'>NOT LICENSED</span>")
            self.h_plan.setText("")
            self.h_exp.setText("")

    def _show_act(self):
        if self._activating:
            return
        self._activating = True
        d = ActivationDialog(None, self.api)
        accepted = d.exec()
        self._activating = False
        if accepted:
            self._resolve_license()
        else:
            QApplication.quit()


# ---------------------------------------------------------------------------
# Entry
# ---------------------------------------------------------------------------

def main():
    app = QApplication(sys.argv)
    app.setStyle("Fusion")
    win = LauncherWindow()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()